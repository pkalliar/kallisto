package gr.mfa.alfasigma.data;

public class Thematologio {

    String fakelos1, thema1;

    public String getFakelos1() {
        return fakelos1;
    }

    public void setFakelos1(String fakelos1) {
        this.fakelos1 = fakelos1;
    }

    public String getThema1() {
        return thema1;
    }

    public void setThema1(String thema1) {
        this.thema1 = thema1;
    }
}
